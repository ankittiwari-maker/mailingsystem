package application;

public class Logger
{
	private String logFile;
	
	
	public Logger()
	{
		this.logFile = "logger.txt";
	}
	
	public void createLogFile()
	{
		
	}
	
	
	public void readLogFile()
	{
		
	}
	
	public static void log()
	{
		
	}

	public String getLogFile() {
		return logFile;
	}
}
